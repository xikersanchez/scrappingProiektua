package com.si.scrapping.scrapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScrappingApplication.class, args);
	}

}
